package com.number.generator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NumberGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
