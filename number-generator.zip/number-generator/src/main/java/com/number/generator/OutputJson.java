package com.number.generator;

public class OutputJson {

	private String result;

	public OutputJson() {
		super();
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
	
}
