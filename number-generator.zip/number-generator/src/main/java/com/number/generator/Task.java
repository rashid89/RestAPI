package com.number.generator;

import java.util.UUID;

public class Task {

	private UUID task;

	public Task() {
		super();
	}

	public UUID getTask() {
		return task;
	}

	public void setTask(UUID task) {
		this.task = task;
	}

}
