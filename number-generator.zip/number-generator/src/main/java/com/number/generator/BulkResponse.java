package com.number.generator;

import java.util.List;

public class BulkResponse {

	private List<String> result;

	public BulkResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<String> getResult() {
		return result;
	}

	public void setResult(List<String> result) {
		this.result = result;
	}
	
}
